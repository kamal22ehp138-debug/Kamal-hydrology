
import { WaterParams, MeqParams, HydrologicalIndices, AssessmentResult } from '../types';

const EQ_WEIGHTS = {
  ca: 20.04,
  mg: 12.153,
  na: 22.99,
  k: 39.1,
  cl: 35.45,
  so4: 48.03,
  hco3: 61.017,
  no3: 62.00,
  f: 18.998
};

// Default weights if not provided by user
export const DEFAULT_WQI_WEIGHTS: Record<string, number> = { 
  ph: 4, tds: 4, ec: 3, ca: 2, mg: 2, na: 2, cl: 3, so4: 4, no3: 5, fe: 4, mn: 4, f: 5, cu: 2, pb: 5, cd: 5, cr: 5, zn: 2, tc: 5,
  po4: 3, b: 3, temp: 1, do: 2, alk: 2, caco3: 2, sio2: 1, tss: 2
};

// Default limits if not provided by user (WHO standards)
export const DEFAULT_WQI_LIMITS: Record<string, number> = { 
  ph: 8.5, tds: 500, ec: 1000, ca: 75, mg: 30, na: 200, cl: 250, so4: 250, no3: 45, fe: 0.3, mn: 0.1, f: 1.5, cu: 1.0, pb: 0.01, cd: 0.003, cr: 0.05, zn: 3.0, tc: 1,
  po4: 0.1, b: 0.7, temp: 30, do: 7, alk: 150, caco3: 150, sio2: 30, tss: 25
};

export const convertToMeq = (params: WaterParams): MeqParams => {
  return {
    ca: params.ca / EQ_WEIGHTS.ca,
    mg: params.mg / EQ_WEIGHTS.mg,
    na: params.na / EQ_WEIGHTS.na,
    k: params.k / EQ_WEIGHTS.k,
    cl: params.cl / EQ_WEIGHTS.cl,
    so4: params.so4 / EQ_WEIGHTS.so4,
    hco3: params.hco3 / EQ_WEIGHTS.hco3,
    no3: params.no3 / EQ_WEIGHTS.no3,
    f: params.f / EQ_WEIGHTS.f
  };
};

export const calculateIndices = (
  params: WaterParams, 
  customLimits: Record<string, number> = DEFAULT_WQI_LIMITS,
  customWeights: Record<string, number> = DEFAULT_WQI_WEIGHTS
): HydrologicalIndices & { meqValues: MeqParams, ionBalanceError: number } => {
  const meq = convertToMeq(params);

  const sar = meq.na / Math.sqrt((meq.ca + meq.mg) / 2);
  const rsc = meq.hco3 - (meq.ca + meq.mg);
  const naPercent = ((meq.na + meq.k) * 100) / (meq.ca + meq.mg + meq.na + meq.k);
  const pi = ((meq.na + Math.sqrt(meq.hco3)) * 100) / (meq.ca + meq.mg + meq.na);
  const mar = (meq.mg * 100) / (meq.ca + meq.mg);
  const mh = mar;
  const kr = meq.na / (meq.ca + meq.mg);
  const th = (2.497 * params.ca) + (4.115 * params.mg);
  const ps = meq.cl + 0.5 * meq.so4;
  const ssp = (meq.na * 100) / (meq.ca + meq.mg + meq.na);
  
  // NPI = (NO3 - Sn) / Sn where Sn = 45 (Standard limit)
  const npi = (params.no3 - 45) / 45;

  // Ion Balance Error Calculation
  const totalCations = meq.ca + meq.mg + meq.na + meq.k;
  const totalAnions = meq.cl + meq.so4 + meq.hco3 + meq.no3 + meq.f;
  const ionBalanceError = totalCations + totalAnions === 0 ? 0 : 
    ((totalCations - totalAnions) / (totalCations + totalAnions)) * 100;

  // Use effective limits and weights (merge custom with defaults to ensure all keys exist)
  const finalWeights = { ...DEFAULT_WQI_WEIGHTS, ...customWeights };
  const finalLimits = { ...DEFAULT_WQI_LIMITS, ...customLimits };
  
  let sumWiQi = 0, sumWi = 0;
  Object.keys(finalWeights).forEach(key => {
    const val = (params as any)[key] !== undefined ? (params as any)[key] : 0;
    const limit = finalLimits[key] || DEFAULT_WQI_LIMITS[key] || 1; // Fallback to avoid division by zero
    const wi = finalWeights[key];
    let qi = 0;

    if (key === 'ph') {
      const idealPH = 7.0;
      qi = 100 * (val - idealPH) / (limit - idealPH);
    } else if (key === 'do') {
      const idealDO = 14.6;
      qi = 100 * (idealDO - val) / (idealDO - limit);
    } else {
      qi = (val / limit) * 100;
    }

    sumWiQi += wi * qi;
    sumWi += wi;
  });
  
  const wqi = sumWiQi / sumWi;

  return { sar, rsc, naPercent, pi, mh, mar, kr, wqi, th, ps, ssp, npi, meqValues: meq, ionBalanceError };
};

export const getFullAssessment = (params: WaterParams, indices: HydrologicalIndices): AssessmentResult => {
  let toxicStatus = { label: "آمن", color: "text-green-600", value: "ضمن الحدود" };
  if (params.pb > 0.01 || params.cd > 0.003 || params.cr > 0.05) {
    toxicStatus = { label: "خطر سام", color: "text-red-600", value: "تجاوز الحدود" };
  }

  let bioStatus = { label: "خالٍ من التلوث", color: "text-green-600", value: params.tc };
  if (params.tc > 0) {
    bioStatus = { label: "ملوث بيولوجياً", color: "text-red-600", value: params.tc };
  }

  return {
    drinking: {
      wqi: { label: indices.wqi < 50 ? "ممتاز" : indices.wqi < 100 ? "جيد" : indices.wqi < 200 ? "رديء" : "غير صالح", color: indices.wqi < 100 ? "text-blue-600" : "text-red-600", value: indices.wqi.toFixed(2) },
      th: { label: indices.th < 150 ? "ناعم" : "عسر", color: indices.th < 150 ? "text-green-600" : "text-orange-600", value: indices.th.toFixed(1) },
      tds: { label: params.tds < 1000 ? "عذب" : "مالح", color: params.tds < 1000 ? "text-green-600" : "text-red-600", value: params.tds },
      npi: { label: indices.npi > 0 ? "تلوث نترات" : "طبيعي", color: indices.npi > 0 ? "text-red-600" : "text-green-600", value: indices.npi.toFixed(2) },
      fluoride: { label: params.f > 1.5 ? "مرتفع" : "آمن", color: params.f > 1.5 ? "text-red-600" : "text-green-600", value: params.f },
      iron: { label: params.fe > 0.3 ? "مرتفع" : "آمن", color: params.fe > 0.3 ? "text-red-600" : "text-green-600", value: params.fe },
      toxicMetals: toxicStatus,
      biological: bioStatus
    },
    irrigation: {
      sar: { label: indices.sar < 10 ? "ممتاز" : "ضعيف", color: indices.sar < 10 ? "text-green-600" : "text-red-600", value: indices.sar.toFixed(2) },
      naPercent: { label: indices.naPercent < 60 ? "جيد" : "رديء", color: indices.naPercent < 60 ? "text-green-600" : "text-red-600", value: indices.naPercent.toFixed(1) + "%" },
      rsc: { label: indices.rsc < 1.25 ? "آمن" : "خطر", color: indices.rsc < 1.25 ? "text-green-600" : "text-red-600", value: indices.rsc.toFixed(2) },
      pi: { label: indices.pi > 75 ? "Class I" : "Class II/III", color: indices.pi > 75 ? "text-green-600" : "text-orange-600", value: indices.pi.toFixed(2) },
      ps: { label: indices.ps < 3 ? "آمن" : "مالح", color: indices.ps < 3 ? "text-green-600" : "text-red-600", value: indices.ps.toFixed(2) },
      ssp: { label: indices.ssp < 60 ? "جيد" : "رديء", color: indices.ssp < 60 ? "text-green-600" : "text-red-600", value: indices.ssp.toFixed(2) },
      kr: { label: indices.kr < 1 ? "مقبول" : "فائض صوديوم", color: indices.kr < 1 ? "text-green-600" : "text-red-600", value: indices.kr.toFixed(2) },
      mar: { label: indices.mar < 50 ? "آمن" : "خطر (MH)", color: indices.mar < 50 ? "text-green-600" : "text-red-600", value: indices.mar.toFixed(1) + "%" },
      boron: { label: params.b < 0.7 ? "آمن" : "سام", color: params.b < 0.7 ? "text-green-600" : "text-red-600", value: params.b }
    },
    livestock: {
      overall: { label: params.tds < 3000 ? "ممتاز" : "مقبول", color: params.tds < 3000 ? "text-green-600" : "text-orange-600", value: params.tds }
    }
  };
};
