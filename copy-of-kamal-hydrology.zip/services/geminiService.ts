
import { GoogleGenAI } from "@google/genai";
import { WaterParams, HydrologicalIndices } from "../types";

export const getAIAnalysis = async (params: WaterParams, indices: HydrologicalIndices, location?: { lat: number, lng: number }) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-pro-preview";

  const prompt = `
    بصفتك عالم هيدرولوجيا وخبير في جودة المياه، قم بإجراء تحليل بحثي معمق للبيانات التالية:
    
    1. الخصائص الفيزيائية: EC: ${params.ec}, Temp: ${params.temp}, DO: ${params.do}, TSS: ${params.tss}.
    2. البصمة الكيميائية: pH: ${params.ph}, TDS: ${params.tds}, Alk: ${params.alk}, CaCO3: ${params.caco3}.
    3. الأيونات الرئيسية: Ca: ${params.ca}, Mg: ${params.mg}, Na: ${params.na}, K: ${params.k}, Cl: ${params.cl}, SO4: ${params.so4}, HCO3: ${params.hco3}.
    4. العناصر السامة والنزرة: Pb: ${params.pb}, Cd: ${params.cd}, Cr: ${params.cr}, Zn: ${params.zn}, Cu: ${params.cu}, B: ${params.b}, F: ${params.f}.
    5. المؤشرات المحسوبة: WQI: ${indices.wqi.toFixed(2)}, SAR: ${indices.sar.toFixed(2)}, RSC: ${indices.rsc.toFixed(2)}, PI: ${indices.pi.toFixed(2)}, MAR: ${indices.mar.toFixed(2)}%.
    
    الموقع الجغرافي الحالي: ${location ? `خط عرض ${location.lat}, خط طول ${location.lng}` : 'غير محدد'}.

    المطلوب منك كباحث:
    - تحليل التداخل الكيميائي وتقييم الصلاحية للشرب والري.
    - اقتراح "فرضية بحثية" (Research Hypothesis) لرسالة ماجستير.
    - صياغة التقرير بلغة علمية عربية رصينة مع ملخص إنجليزي في النهاية.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 32768 },
        tools: location ? [{ googleSearch: {} }] : []
      },
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "حدث خطأ أثناء إجراء التحليل البحثي المعمق.";
  }
};

export const getDeveloperChatResponse = async (userMessage: string, history: {role: 'user' | 'model', parts: {text: string}[]}[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-pro-preview";

  const systemInstruction = `
    أنت الآن "المهندس المطور وخبير الهيدرولوجيا" لمنصة Kamal Hydrology. 
    وظيفتك هي التفاعل مع المستخدم (الباحث) لمناقشة تطوير التطبيق.
    - إذا طلب إضافة معادلات جديدة (مثل مؤشرات ري أخرى)، اشرح له كيف يمكن دمجها علمياً.
    - إذا اقترح تعديلات في الواجهة، ناقشه في تحسين تجربة المستخدم.
    - كن متعاوناً جداً، تقنياً، وعالماً في مجال الهيدرولوجيا.
    - لغتك هي العربية العلمية الودودة.
  `;

  try {
    const chat = ai.chats.create({
      model: model,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      }
    });

    const response = await chat.sendMessage({ message: userMessage });
    return response.text;
  } catch (error) {
    console.error("Dev Chat Error:", error);
    return "عذراً، واجهت مشكلة في الاتصال بمركز التطوير حالياً.";
  }
};
